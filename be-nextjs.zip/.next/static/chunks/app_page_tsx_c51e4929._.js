(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/app_page_tsx_c51e4929._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/app_page_tsx_c51e4929._.js",
  "chunks": [
    "static/chunks/[turbopack]_browser_dev_hmr-client_hmr-client_ts_317ae783._.js",
    "static/chunks/node_modules_2b005cf2._.js",
    "static/chunks/app_c2ff067d._.js",
    "static/chunks/app_components_362ae4f4._.css"
  ],
  "source": "dynamic"
});
